﻿using Backend.DTO;
using Backend.Models;
using Backend.Repositories;
using Backend.Repositories.IRepositories;
using Backend.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        private readonly IJwtService _jwtService;
        public UserController(IUserRepository userRepository,IJwtService jwtService)
        {
            _userRepository = userRepository;
            _jwtService = jwtService;
        }

        [HttpPost("login")]
        public IActionResult Login(DtoLogin dto)
        {
            User? user;
            if (!ModelState.IsValid)
            {
                IEnumerable<string> errors = ModelState.Values.SelectMany(v => v.Errors).Select(x => x.ErrorMessage);
                BadRequest(errors);
            }
            if (dto.Email != null)
            {
                try
                {
                    user = _userRepository.GetUserByEmailAsync(dto.Email);
                }
                catch (Exception)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, new { message = "error server" });
                }
                if (user == null)
                {
                    return BadRequest(new { message = "invalid credentials" });
                }
                if (!BCrypt.Net.BCrypt.Verify(dto.Password, user.Password))
                {
                    return BadRequest(new { message = "invalid credentials" });
                }
            }
            else
            {
                return BadRequest(new { message = "the email is empty" });
            }
            var jwt = _jwtService.Generate(user.Id);
            Response.Cookies.Append("jwt", jwt, new CookieOptions
            {
                HttpOnly = true
            });
            return Ok(new
            {
                message = "success",
                name=user.Name,
                jwt,
            });
        }
        [HttpGet("user")]
        public IActionResult UserLogin()
        {
            try
            {
                var jwt = Request.Cookies["jwt"];
                if (jwt == null)
                {
                    throw new Exception();
                }
                var token = _jwtService.Verify(jwt);
                var userId = int.Parse(token.Issuer);

                return Ok(_userRepository.GetUserByIdAsync(userId));

            }
            catch (Exception)
            {
                return Unauthorized();
            }
        }

        [HttpPost("logout")]
        public IActionResult Logout()
        {
            Response.Cookies.Delete("jwt");
            return Ok(new
            {
                message = "sucseed"
            });
        }
    }

}
