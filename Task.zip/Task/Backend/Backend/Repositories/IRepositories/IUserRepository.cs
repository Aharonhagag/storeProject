﻿using Backend.Models;

namespace Backend.Repositories.IRepositories
{
    public interface IUserRepository
    {
        List<User> GetUserAsync();
        User GetUserByEmailAsync(string email);
        User GetUserByIdAsync(int id);
    }
}
