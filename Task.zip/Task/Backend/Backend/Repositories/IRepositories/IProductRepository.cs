﻿using Backend.DTO;
using Backend.Models;

namespace Backend.Repositories.IRepositories
{
    public interface IProductRepository
    {
        
        List<Product> GetProducts();
        List<Product> GetAllProducts();
        Task<Product> AddProduct(Product product);
        Task<Product> UpdateProduct(Product product);
        Task<Product> DeleteProduct(Product product);
       Product GetProductById(int id);

    }
}
