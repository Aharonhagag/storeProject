﻿
using Backend.DTO;
using Backend.Models;
using Backend.Repositories.IRepositories;
using JsonSerializer = System.Text.Json.JsonSerializer;

namespace Backend.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private IEnumerable<Product> _products;
        private readonly string _jsonFilePath = "Data/ProductList.json";
        private static int _id = 0;
        public ProductRepository()
        {
            _products = GetProductsFromFileAsync().Result;
        }

        public List<Product> GetProducts()
        {

            return _products.Where(p => p.ReleaseDate <= DateTime.Now).ToList();
        }

        private async Task<List<Product>> GetProductsFromFileAsync()
        {
            try
            {
                if (string.IsNullOrEmpty(_jsonFilePath))
                {
                    throw new ArgumentException("Data file path not set. Please set the _dataFilePath property before calling this method.");
                }

                using (var fileStream = File.OpenRead(_jsonFilePath))
                using (var streamReader = new StreamReader(fileStream))
                {
                    var products = await JsonSerializer.DeserializeAsync<List<Product>>(fileStream);
                    return products;
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to read card data from file '{_jsonFilePath}': {ex.Message}");
            }
        }

        public async Task<Product> AddProduct(Product product)
        {
            product.Id = _id;
            _id++;
            _products = _products.Append(product);
            return await SaveToJson(product);


        }

        public async Task<Product> UpdateProduct(Product product)
        {
            Product productToUpdate = _products.FirstOrDefault(p => p.Id == product.Id);
            if (productToUpdate != null)
            {
                productToUpdate.Name = product.Name;
                productToUpdate.Description = product.Description;
                productToUpdate.Price = product.Price;
                productToUpdate.ReleaseDate = product.ReleaseDate;
                productToUpdate.Image = product.Image;
            }
            return await SaveToJson(product);

        }

        public async Task<Product> DeleteProduct(Product product)
        {
            Product productToDelete = _products.FirstOrDefault(p => p.Id == product.Id);
            if (productToDelete == null)
            {
                throw new Exception();
            }

            _products = _products.Where(p => p.Id != product.Id);
            return await SaveToJson(product);

        }

        private async Task<Product> SaveToJson(Product product)
        {
            await using (FileStream createStream = new FileStream(_jsonFilePath, FileMode.Truncate, FileAccess.Write))
            {
                await JsonSerializer.SerializeAsync(createStream, _products);

            }
            return product;
        }

        public List<Product> GetAllProducts()
        {
            return _products.ToList();
        }

        public Product GetProductById(int id)
        {
            return _products.FirstOrDefault(p => p.Id == id);
        }
    }
}
