﻿using Backend.DTO;
using Backend.Models;
using Backend.Repositories.IRepositories;
using Formatting = Newtonsoft.Json.Formatting;
using JsonSerializer = System.Text.Json.JsonSerializer;

namespace Backend.Repositories
{
    public class UserRepository:IUserRepository
    {
        private IEnumerable<User> _users;
        private readonly string _jsonFilePath = "Data/UserList.json";
        public UserRepository()
        {
            _users= GetUsersFromFileAsync().Result;
        }
        public List<User> GetUserAsync()
        {

            return _users.ToList();
        }
        public User GetUserByEmailAsync(string email)
        {
            return _users.Where(x=>x.Email == email).FirstOrDefault();
        }
        public User GetUserByIdAsync(int id)
        {
            return _users.Where(x => x.Id == id).FirstOrDefault();
        }



        private async Task<List<User>> GetUsersFromFileAsync()
        {
            try
            {
                if (string.IsNullOrEmpty(_jsonFilePath))
                {
                    throw new ArgumentException("Data file path not set. Please set the _dataFilePath property before calling this method.");
                }

                using (var fileStream = File.OpenRead(_jsonFilePath))
                using (var streamReader = new StreamReader(fileStream))
                {
                    var users = await JsonSerializer.DeserializeAsync<List<User>>(fileStream);
                    foreach (var user in users)
                    {
                        user.Password = BCrypt.Net.BCrypt.HashPassword(user.Password);
                    }
                    return users;
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to read User data from file '{_jsonFilePath}': {ex.Message}");
            }
        }
    }
}
