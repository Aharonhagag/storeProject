import React from 'react';

export default function ProductRow({ product, onEdit, onDelete }) {
  return (
    <tr className="bg-white border-b border-gray-200 hover:bg-gray-50">
      <td className="py-3 px-4 text-left text-black">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-16 h-16 object-cover rounded-lg shadow-md"
        />
      </td>
      <td className="py-3 px-4 text-black">{product.name}</td>
      <td className="py-3 px-4 text-black">{product.description}</td>
      <td className="py-3 px-4 text-black">${product.price.toFixed(2)}</td>
      <td className="py-3 px-4 text-black">{new Date(product.releaseDate).toLocaleDateString()}</td>
      <td className="py-3 px-4 text-center">
        <button
          onClick={() => onEdit(product.id)}
          className="bg-yellow-500 hover:bg-yellow-600 text-white font-semibold py-2 px-4 rounded-lg transform transition-transform duration-300 hover:scale-105"
        >
          Edit
        </button>
        <button
          onClick={() => onDelete(product)}
          className="bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-lg transform transition-transform duration-300 hover:scale-105 ml-2"
        >
          Delete
        </button>
      </td>
    </tr>
  );
}
