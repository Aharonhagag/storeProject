import React from "react";
import Link from "next/link";
import { useAuth } from "../context/AuthContext";
import { useRouter } from "next/router";
import {
  HomeIcon,
  UserCircleIcon,
  ArrowRightOnRectangleIcon,
} from "@heroicons/react/24/solid";

export default function Header() {
  const { isAuthenticated, logout } = useAuth();
  const router = useRouter();

  return (
    <header className="flex justify-between items-center py-4 px-8 bg-gray-900 text-white shadow-lg">
      <Link href="/">
        <div className="text-2xl font-bold cursor-pointer flex items-center space-x-2 hover:text-gray-400 transition-colors">
          <HomeIcon className="h-6 w-6" />
          <span>HOME</span>
        </div>
      </Link>
      <div className="space-x-2 flex items-center">
        {isAuthenticated ? (
          <>
            <Link href="/admin">
              <button className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-800 text-white font-semibold py-2 px-4 rounded-lg transition-transform transform hover:scale-105">
                <UserCircleIcon className="h-6 w-6" />
                <span>Admin Page</span>
              </button>
            </Link>
            <button
              onClick={logout}
              className="flex items-center space-x-2 bg-red-600 hover:bg-red-800 text-white font-semibold py-2 px-4 rounded-lg transition-transform transform hover:scale-105"
            >
              <ArrowRightOnRectangleIcon className="h-6 w-6" />{" "}
              <span>Logout</span>
            </button>
          </>
        ) : (
          <Link href="/login">
            <button className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-800 text-white font-semibold py-2 px-4 rounded-lg transition-transform transform hover:scale-105">
              <UserCircleIcon className="h-6 w-6" />
              <span>Login as Admin</span>
            </button>
          </Link>
        )}
      </div>
    </header>
  );
}
