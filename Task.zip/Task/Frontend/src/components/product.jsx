export default function ProductCard({ product }) {
  return (
    <div className="border rounded-lg p-4 shadow-lg">
      <img
        src={product.image}
        alt={product.name}
        width={400}
        height={400}
        className="w-full h-auto object-cover rounded-t-lg"
      />
      <h2 className="text-xl font-semibold mt-4">{product.name}</h2>
      <p className="text-gray-700">{product.description}</p>
      <p className="text-lg font-bold mt-4">{product.price}$</p>
    </div>
  );
}
