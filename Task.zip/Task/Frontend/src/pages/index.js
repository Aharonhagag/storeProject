import ProductCard from "../components/product";

export async function getStaticProps() {
  let products = [];

  try {
    const res = await fetch("http://localhost:5286/api/product");

    if (res.ok) {
      products = await res.json();
    } else {
      console.error(
        `Failed to fetch products: ${res.status} ${res.statusText}`
      );
    }
  } catch (error) {
    console.error("Error fetching products:", error);
  }

  return {
    props: {
      products,
    },
    revalidate: 60,
  };
}

export default function Home({ products }) {
  return (
    <div className="min-h-screen bg-black text-white">
      <div className="relative bg-gradient-to-r from-gray-900 to-black text-white h-96 flex items-center justify-center overflow-hidden">
        <img
          src="https://phoenixcellular.com/wp-content/uploads/2022/09/overview__bcphzsdb4fpu_og.png"
          alt="Hero background"
          className="absolute inset-0 w-full h-full object-cover opacity-60"
        />
        <div className="relative z-10 text-center p-8 bg-black bg-opacity-60 rounded-lg">
          <h1 className="text-5xl md:text-7xl font-extrabold mb-6 leading-tight">
            Welcome to Our Store
          </h1>
          <p className="text-lg md:text-2xl mb-6">
            Discover the best products and deals just for you!
          </p>
        </div>
      </div>

      <section className="py-16 bg-gray-800">
        <h1 className="text-4xl font-extrabold mb-12 text-center text-white">
          Our Products
        </h1>

        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto text-center">
          <p className="mb-4">
            &copy; 2024 Your Store Name. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
