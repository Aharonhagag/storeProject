import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import ProductRow from "../components/productRow";

export async function getStaticProps() {
  let products = [];

  try {
    const res = await fetch("http://localhost:5286/api/product/all");
    if (res.ok) {
      products = await res.json();
    } else {
      console.error(
        `Failed to fetch products: ${res.status} ${res.statusText}`
      );
    }
  } catch (error) {
    console.error("Error fetching products:", error);
  }

  return {
    props: {
      products,
    },
    revalidate: 60,
  };
}

export default function Admin({ products }) {
  const router = useRouter();
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("token");

    if (!token) {
      router.push("/login");
    } else {
      setIsAuthenticated(true);
    }
  }, [router]);

  if (!isAuthenticated) {
    return <p className="text-center text-gray-700">Loading...</p>;
  }

  const handleEdit = (id) => {
    console.log(`Editing product with ID: ${id}`);
    router.push(`/updateProduct/${id}`);
  };

  const handleDelete = async (product) => {
    try {
      const res = await fetch(`http://localhost:5286/api/product`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(product),
      });

      if (res.ok) {
        router.reload();
      } else {
        console.error(
          `Failed to delete product: ${res.status} ${res.statusText}`
        );
      }
    } catch (error) {
      console.error("Error deleting product:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-4xl font-extrabold mb-8 text-center text-gray-900">
        Admin - Product Management
      </h1>
      <div className="mb-6 text-center">
        <button
          onClick={() => router.push("/addProduct")}
          className="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-6 rounded-lg transform transition-transform duration-300 hover:scale-105"
        >
          Add Product
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white shadow-md rounded-lg border border-gray-200">
          <thead>
            <tr>
              <th className="py-3 px-4 border-b-2 border-gray-200 bg-gray-100 text-left text-sm font-semibold text-gray-700">
                Image
              </th>
              <th className="py-3 px-4 border-b-2 border-gray-200 bg-gray-100 text-left text-sm font-semibold text-gray-700">
                Name
              </th>
              <th className="py-3 px-4 border-b-2 border-gray-200 bg-gray-100 text-left text-sm font-semibold text-gray-700">
                Description
              </th>
              <th className="py-3 px-4 border-b-2 border-gray-200 bg-gray-100 text-left text-sm font-semibold text-gray-700">
                Price
              </th>
              <th className="py-3 px-4 border-b-2 border-gray-200 bg-gray-100 text-left text-sm font-semibold text-gray-700">
                Release Date
              </th>
              <th className="py-3 px-4 border-b-2 border-gray-200 bg-gray-100 text-left text-sm font-semibold text-gray-700">
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <ProductRow
                key={product.id}
                product={product}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
