import { useState, useEffect } from "react";
import { useRouter } from "next/router";
import Link from "next/link";

export default function UpdateProduct() {
  const [product, setProduct] = useState({
    name: "",
    price: "",
    description: "",
    image: "",
    releaseDate: "",
  });
  const [error, setError] = useState(null);
  const router = useRouter();
  const { id } = router.query;

  useEffect(() => {
    if (id) {
      fetchProduct(id);
    }
  }, [id]);

  const fetchProduct = async (id) => {
    try {
      const res = await fetch(`http://localhost:5286/api/product/${id}`);
      if (res.ok) {
        const data = await res.json();
        setProduct({
          name: data.name,
          price: data.price,
          description: data.description,
          image: data.image,
          releaseDate: data.releaseDate.split("T")[0], // Format date for input
        });
      } else {
        setError("Failed to fetch product details.");
      }
    } catch (err) {
      setError("An unexpected error occurred while fetching the product.");
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProduct((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (validateForm()) {
      try {
        const res = await fetch(`http://localhost:5286/api/product`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ id, ...product }),
        });

        if (res.ok) {
          router.push("/admin");
        } else {
          setError("Failed to update the product.");
        }
      } catch (err) {
        setError("An unexpected error occurred while updating the product.");
      }
    }
  };

  const validateForm = () => {
    const { name, price, description, image, releaseDate } = product;
    if (!name || !description || !image || !releaseDate) {
      setError("Please fill out all required fields.");
      return false;
    }
    if (price <= 0) {
      setError("Price must be a positive number.");
      return false;
    }
    return true;
  };

  return (
    <div className="max-w-lg mx-auto mt-10 p-8 bg-white dark:bg-gray-900 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700">
      <h2 className="text-3xl font-extrabold mb-8 text-center text-gray-900 dark:text-white">
        Update Product
      </h2>
      {error && <p className="text-red-500 mb-6 text-center">{error}</p>}
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="mb-6">
          <label
            className="block text-gray-700 dark:text-gray-300 text-base font-semibold mb-2"
            htmlFor="name"
          >
            Name
          </label>
          <input
            id="name"
            name="name"
            type="text"
            value={product.name}
            onChange={handleChange}
            required
            className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-600 text-gray-800 dark:text-black"
          />
        </div>
        <div className="mb-6">
          <label
            className="block text-gray-700 dark:text-gray-300 text-base font-semibold mb-2"
            htmlFor="price"
          >
            Price
          </label>
          <input
            id="price"
            name="price"
            type="number"
            value={product.price}
            onChange={handleChange}
            required
            className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-600 text-gray-800 dark:text-black"
          />
        </div>
        <div className="mb-6">
          <label
            className="block text-gray-700 dark:text-gray-300 text-base font-semibold mb-2"
            htmlFor="description"
          >
            Description
          </label>
          <textarea
            id="description"
            name="description"
            value={product.description}
            onChange={handleChange}
            required
            className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-600 text-gray-800 dark:text-black"
          />
        </div>
        <div className="mb-6">
          <label
            className="block text-gray-700 dark:text-gray-300 text-base font-semibold mb-2"
            htmlFor="image"
          >
            Image URL
          </label>
          <input
            id="image"
            name="image"
            type="text"
            value={product.image}
            onChange={handleChange}
            required
            className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-600 text-gray-800 dark:text-black"
          />
        </div>
        <div className="mb-6">
          <label
            className="block text-gray-700 dark:text-gray-300 text-base font-semibold mb-2"
            htmlFor="releaseDate"
          >
            Release Date
          </label>
          <input
            id="releaseDate"
            name="releaseDate"
            type="date"
            value={product.releaseDate}
            onChange={handleChange}
            required
            className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-600 text-gray-800 dark:text-black"
          />
        </div>
        <button
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition-transform transform hover:scale-105"
        >
          Update Product
        </button>
        <Link href="/admin" passHref>
          <div className="mt-4 block text-center w-full bg-gray-600 hover:bg-gray-700 text-white font-bold py-3 px-6 rounded-lg transition-transform transform hover:scale-105 cursor-pointer">
            Cancel
          </div>
        </Link>
      </form>
    </div>
  );
}
